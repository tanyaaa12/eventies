# Event-webpage
It is made with help of HTML, CSS and JS
https://event-organiser120.netlify.app/
